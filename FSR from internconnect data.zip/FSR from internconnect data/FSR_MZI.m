clc
clear all
close all
% 
data_MZ=load("FSR_MZI_Interconnect.txt");
data_Mich=load("FSR_Mich_Interconnect.txt");

format long

n_eff=2.44;
n_g=4.22;
lambda=1550*1e-9;
beta=2*pi*n_eff/lambda;

n=linspace(1,2000);
% MZI
DeltaL_MZ=2*pi*n./beta;
FSR_MZ=lambda^2./(DeltaL_MZ*n_g);

% Michelson
DeltaL_Mich=pi*(n-1/2)./beta;
FSR_Mich=lambda^2./(2*DeltaL_Mich*n_g);

figure('Position',[600 600 500 400]);
set(gcf,'color','w')
semilogy(DeltaL_MZ*1e6,FSR_MZ*1e9,'k',LineWidth=1),hold on
semilogy(data_MZ(:,1),data_MZ(:,2),'+k','MarkerSize',10,LineWidth=2)
semilogy(DeltaL_Mich*1e6,FSR_Mich*1e9,'b',LineWidth=1),hold on
semilogy(data_Mich(:,1),data_Mich(:,2),'+b','MarkerSize',10,LineWidth=2)
ylabel('FSR [nm]')
xlabel('$\Delta$L [$\mu$m]')
legend('Theory MZI','Interconnect MZI','Theory MichI','Interconnect MichI')
