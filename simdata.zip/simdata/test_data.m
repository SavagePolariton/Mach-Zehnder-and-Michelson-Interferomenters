clc
close all
clear all

load("simdata_Mich5.mat");

wv=t1.wavelength;
for ii=1:length(wv)
gain(ii)=t1.TE_gain__dB_(1,1,ii);
end

figure
plot(wv,gain)